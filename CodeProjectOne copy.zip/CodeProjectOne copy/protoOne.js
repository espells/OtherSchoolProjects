$(document).ready(function){
  $(".startSurvey").onclick(function){
    "window.location.href = 'http://www.google.com'"
  }




}
